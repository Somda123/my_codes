document.addEventListener("DOMContentLoaded", () => {
    const cells = document.querySelectorAll(".cell");
    const resetButton = document.getElementById("resetButton");
    const messageScreen = document.getElementById("messageScreen");
    const resultMessage = document.getElementById("resultMessage");
    const newGameButton = document.getElementById("newGameButton");
    let currentPlayer = "X";
    let gameActive = true;
    const boardState = Array(9).fill("");

    const winningConditions = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ];

    function handleCellClick(event) {
        const cell = event.target;
        const index = cell.getAttribute("data-index");

        if (boardState[index] !== "" || !gameActive) return;

        cell.textContent = currentPlayer;
        boardState[index] = currentPlayer;

        if (checkWin()) {
            showResult(`${currentPlayer} wins!`);
            gameActive = false;
        } else if (boardState.every(cell => cell !== "")) {
            showResult("It's a draw!");
            gameActive = false;
        }

        currentPlayer = currentPlayer === "X" ? "O" : "X";
    }

    function checkWin() {
        return winningConditions.some(condition => {
            const [a, b, c] = condition;
            return boardState[a] && boardState[a] === boardState[b] && boardState[a] === boardState[c];
        });
    }

    function resetGame() {
        boardState.fill("");
        cells.forEach(cell => (cell.textContent = ""));
        currentPlayer = "X";
        gameActive = true;
        messageScreen.style.display = "none";
    }

    function showResult(message) {
        resultMessage.textContent = message;
        messageScreen.style.display = "flex";
    }

    cells.forEach(cell => cell.addEventListener("click", handleCellClick));
    resetButton.addEventListener("click", resetGame);
    newGameButton.addEventListener("click", resetGame);
});
